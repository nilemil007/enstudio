(function($) {
  'use strict';
  $(function() {

    if($('.perfect-scrollbar-example').length) {
      var scrollbarExample = new PerfectScrollbar('.perfect-scrollbar-example');
    }

  });
})(jQuery);