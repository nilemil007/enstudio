<x-app-layout>
    <h1>Dashboard</h1>
</x-app-layout>
